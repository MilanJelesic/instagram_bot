import os
from sys import platform
from scrapy.selector import Selector
from selenium import webdriver
from selenium.webdriver.firefox.options import Options
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.firefox.firefox_binary import FirefoxBinary
import time
import tkinter as tk
from tkinter import filedialog as fd
from tkinter import ttk
from tkinter import messagebox
from datetime import datetime
from openpyxl import Workbook
import config
import json
import requests
import pickle

import base64

from threading import Thread



class instaApi:
    def __init__(self):
        global running
        running = False

        
    def init_UI(self):
        root = tk.Tk()
        root.title('Instagram Bot')
        root.geometry('800x480')

        fontStyle = ("Lucida Grande", 10)

        frame0 = tk.Frame(master=root)
        frame0.pack(fill=tk.X,padx=10, pady=2)

        username_text = tk.Label(frame0, text='Username: ',font=fontStyle)
        username_text.pack(side=tk.LEFT)

        self.username_entry = tk.Entry(frame0, width=20) 
        self.username_entry.pack(side=tk.LEFT)

        password_text = tk.Label(frame0, text='Password: ',font=fontStyle)
        password_text.pack(side=tk.LEFT)

        self.password_entry = tk.Entry(frame0, width=20, show='*') 
        self.password_entry.pack(side=tk.LEFT)

        if os.path.exists('config'):
            with open('config','rb') as f:
                load_file = pickle.load(f)
                username = load_file['username']
                password = base64.b64decode(load_file['password'])
                self.username_entry.insert(0,username)
                self.password_entry.insert(0,password)

        save_button = tk.Button(frame0,text='Save',width=10,command=self.save_password)
        save_button.pack(side=tk.LEFT)

        frame1 = tk.Frame(master=root)
        frame1.pack(fill=tk.X,padx=10, pady=2)
        
        
        label1 = tk.Label(frame1, text='Keywords: ',font=fontStyle)
        label1.pack(side=tk.LEFT)

        self.keyword = tk.Entry(frame1, width=20) 
        self.keyword.pack(side=tk.LEFT)
    
        label1 = tk.Label(frame1, text='Max Followers: ',font=fontStyle)
        label1.pack(side=tk.LEFT)

        self.max_follow = tk.Entry(frame1, width=10) 
        self.max_follow.pack(side=tk.LEFT)

        label1 = tk.Label(frame1, text='Min Followers: ',font=fontStyle)
        label1.pack(side=tk.LEFT)

        self.min_follow = tk.Entry(frame1, width=10) 
        self.min_follow.pack(side=tk.LEFT) 

        frame2 = tk.Frame(master=root)
        frame2.pack(fill=tk.X,padx=10, pady=2)

    
        label1 = tk.Label(frame2, text='Max Likes: ',font=fontStyle)
        label1.pack(side=tk.LEFT)

        self.max_like = tk.Entry(frame2, width=10) 
        self.max_like.pack(side=tk.LEFT)  

        label1 = tk.Label(frame2, text='Min Likes: ',font=fontStyle)
        label1.pack(side=tk.LEFT)

        self.min_like = tk.Entry(frame2, width=10) 
        self.min_like.pack(side=tk.LEFT)       


        self.check_button = tk.Button(
            frame1,
            text='Start',
            width=10,
            bg='green',
            command=self.start
        )
        self.check_button.pack(side=tk.RIGHT)

        output_frame = tk.Frame(root)
        v_scrollbar = tk.Scrollbar(output_frame, orient=tk.VERTICAL, jump=1)
        h_scrollbar = tk.Scrollbar(output_frame, orient=tk.HORIZONTAL, jump=1)

        self.my_tree = ttk.Treeview(output_frame,yscrollcommand=v_scrollbar.set,xscrollcommand=h_scrollbar.set)

        v_scrollbar.config(command=self.my_tree.yview)
        v_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

        

        h_scrollbar.config(command=self.my_tree.xview)
        h_scrollbar.pack(side=tk.BOTTOM, fill=tk.X)

        all_columns = ['count','username','link','followers','likes']
        self.my_tree['columns'] = all_columns
        
        self.my_tree.column("#0",width=0, stretch=0)
        self.my_tree.column('count', anchor=tk.W, width=20, minwidth=20)
        self.my_tree.column('username', anchor=tk.W, width=40, minwidth=40)
        self.my_tree.column('link', anchor=tk.W, width=100, minwidth=100)
        self.my_tree.column('followers',anchor=tk.W,width=120, minwidth=50)
        self.my_tree.column('likes',anchor=tk.W,width=120, minwidth=50)

        self.my_tree.heading('#0', text='', anchor=tk.W)
        self.my_tree.heading('count', text="Count", anchor=tk.W)
        self.my_tree.heading('username', text="Username", anchor=tk.W)
        self.my_tree.heading('link', text='Link', anchor=tk.CENTER)
        self.my_tree.heading('followers', text='Followers',anchor=tk.W)
        self.my_tree.heading('likes', text='Likes',anchor=tk.W)
 
        self.my_tree.pack(fill=tk.BOTH, expand=True)
        output_frame.pack(fill=tk.BOTH, expand=True)
            

        # my_menu = tk.Menu(root)
        # root.config(menu=my_menu)
        
        # about_text = 'Amazon Asin Marketplace Checker Tool \nDevloper: Prakash \nContact: https://www.fiverr.com/prakashtech250'
        # my_menu.add_command(label="About", command=lambda: self.print_information(about_text))
        # my_menu.add_command(label="Exit", command=lambda: self.exit_window(root))
        root.mainloop()
    
    def save_password(self):
        username_get = self.username_entry.get()
        password_get = self.password_entry.get()
        password = password_get.encode("utf-8")
        encoded_password = base64.b64encode(password)
        login_text = {}
        login_text['username'] = username_get
        login_text['password'] = encoded_password
        with open('config', 'wb') as json_file:
            pickle.dump(login_text, json_file)
        self.print_information('Username and password are saved.')

    def create_filename(self, keyword):
        if not os.path.exists('output'):
            os.makedirs('output')
        now = datetime.now()
        dt_string = now.strftime("%Y%m%d_%H_%M")
        filename = 'output/{}_{}.xlsx'.format(keyword,dt_string)
        return filename

    def insert(self, data):
        self.my_tree.insert(parent='', index='end', iid=self.iid, text='', values=data)
        self.my_tree.yview_moveto(1)
        
    def open_browser(self) :
        options = Options()
        options.add_argument("--incognito")
        options.headless = True
        print('opening browser. Please wait.....')
        if platform == 'linux':
            driver_path = '{}/driver/geckodriver_linux'.format(os.getcwd())
            self.driver = webdriver.Firefox(options=options,executable_path=r'{}'.format(driver_path))
        elif platform == 'win32' or platform == 'win':
            driver_path = '{}/driver/geckodriver.exe'.format(os.getcwd())
            try:
                options.binary_location = r'C:/Program Files/Mozilla Firefox/firefox.exe'
                self.driver = webdriver.Firefox(options=options,executable_path=r'{}'.format(driver_path))
            except:
               options.binary_location = r'C:/Program Files (x86)/Mozilla Firefox/firefox.exe' 
               self.driver = webdriver.Firefox(options=options,executable_path=r'{}'.format(driver_path)) 
        else:
            driver_path = '{}/driver/geckodriver_mac'.format(os.getcwd())
            self.driver = webdriver.Firefox(options=options,executable_path=r'{}'.format(driver_path))



    def get_page_source(self,url):
        try:
            self.driver.get(url)
            page_source = self.driver.page_source
            res = Selector(text=page_source)
            return res
            
        except Exception as e:
            print('Error: {}'.format(e))
    
    def login(self):
        #target username
        username_elem = WebDriverWait(self.driver, 10).until(EC.element_to_be_clickable((By.CSS_SELECTOR, "input[name='username']")))
        password_elem = WebDriverWait(self.driver, 10).until(EC.element_to_be_clickable((By.CSS_SELECTOR, "input[name='password']")))

        username_get = self.username_entry.get()
        password_get = self.password_entry.get()
        #enter username and password
        username_elem.clear()
        username_elem.send_keys(username_get)
        password_elem.clear()
        password_elem.send_keys(password_get)

        #target the login button and click it
        time.sleep(2)
        button = WebDriverWait(self.driver, 2).until(EC.element_to_be_clickable((By.CSS_SELECTOR, "button[type='submit']"))).click()

        #We are logged in!
        time.sleep(2)
        alert = WebDriverWait(self.driver, 15).until(EC.element_to_be_clickable((By.XPATH, '//button[contains(text(), "Not Now")]'))).click()
        alert = WebDriverWait(self.driver, 15).until(EC.element_to_be_clickable((By.XPATH, '//button[contains(text(), "Not Now")]'))).click()

    def get_followers(self):
        follower_link = WebDriverWait(self.driver, 15).until(EC.element_to_be_clickable((By.XPATH, '/html/body/div[1]/section/main/div/header/section/ul/li[2]/a')))
        follower_count = self.driver.find_element_by_css_selector('#react-root > section > main > div > header > section > ul > li:nth-child(2) > a > span')
        no_followers = follower_count.get_attribute('title').replace(',','')
        return int(no_followers)

    def get_pages(self, keyword):
        output = []
        input_search = WebDriverWait(self.driver, 15).until(EC.element_to_be_clickable((By.XPATH, '//input[@placeholder="Search"]')))
        input_search.send_keys(keyword)
        time.sleep(0.5)
        # result_elements = self.driver.find_elements_by_xpath('/html/body/div[1]/section/nav/div[2]/div/div/div[2]/div[3]/div/div[2]/div/div/a')
        result_check = WebDriverWait(self.driver, 15).until(EC.visibility_of_element_located((By.XPATH, '/html/body/div[1]/section/nav/div[2]/div/div/div[2]/div[3]/div/div[2]/div/div/a')))
        result_elements = self.driver.find_elements_by_xpath('/html/body/div[1]/section/nav/div[2]/div/div/div[2]/div[3]/div/div[2]/div/div/a')
        for result_element in result_elements:
            page = result_element.get_attribute('href')
            output.append(page)
        return output

    def delete_all_data(self):
        x=self.my_tree.get_children()
        for item in x:
            self.my_tree.delete(item)

    def start(self):
        global running 
        username_get = self.username_entry.get()
        password_get = self.password_entry.get()
        if len(username_get) > 0 and len(password_get) > 0:
            if running == False:
                self.id = 1
                self.iid = 0
                self.delete_all_data()
                t1 = Thread(target=self.main)
                t1.start()
            else:
                self.print_warning('Script is running. Please wait.')
        else:
            self.print_warning('Enter login username and password!!!')

    def stop(self):
        global running
        if messagebox.askokcancel("Stop", "Do you want to Stop?"):
            if running:
                running = False
                self.check_button.config(text='Start',bg='green',command=self.start)
                self.driver.quit()
    
    def finish_task(self, filename):
        global running
        running = False
        self.driver.quit()
        self.check_button.config(text='Start',bg='green',command=self.start)
        self.print_information('Task is completed. \nOutput is saved as {}'.format(filename))

    def print_information(self, message):
        messagebox.showinfo("Information",message)
    
    def print_warning(self, message):
        messagebox.showwarning('Warning', message)

    def get_average_likes(self):
        total_likes = 0
        n_scrolls = 2
        # for j in range(0, n_scrolls):
        #     self.driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
        #     time.sleep(5)
        #target all the link elements on the page
        anchors = self.driver.find_elements_by_tag_name('a')
        anchors = [a.get_attribute('href') for a in anchors]
        #narrow down all links to image links only
        anchors = [a for a in anchors if str(a).startswith("https://www.instagram.com/p/")]
        count = 0
        for a in anchors:
            if count == 10:
                break
            else:
                self.driver.get(a)
                time.sleep(2)
                try:
                    try:
                        likes_elem = WebDriverWait(self.driver, 15).until(EC.visibility_of_element_located((By.CSS_SELECTOR, '.zV_Nj span')))
                    except:
                        likes_elem = WebDriverWait(self.driver, 15).until(EC.visibility_of_element_located((By.CSS_SELECTOR, '.vcOH2 span')))
                    int_likes = int(likes_elem.text.replace(',',''))
                    print('{}: {}'.format(a, int_likes))
                    total_likes += int_likes
                    count += 1
                except Exception as e:
                    print('Error: {}'.format(e))
                    pass
        print('Average likes of {} images: '.format(count))
        average_likes = total_likes / count
        return average_likes
    
    def get_page_details(self, url, session):
        total_likes = 0
        headers = {
            'user-agent': 'Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)'
        }
        json_url = url + '?__a=1'
        response = session.get(json_url, headers=headers)
        if response.status_code == 200:
            json_data = json.loads(response.text)
            user = json_data.get('graphql').get('user')
            follower = user.get('edge_followed_by').get('count')
            medias = user.get('edge_owner_to_timeline_media').get('edges')
            like_count = 0
            for m in medias:
                media_like = m.get('node').get('edge_liked_by').get('count')
                like_count += 1
                total_likes += media_like
            if like_count == 0:
                average_like = 0
            else:
                average_like = total_likes / like_count
            return follower, average_like
    
    def get_cookies(self):
        cookies = self.driver.get_cookies()
        s = requests.Session()
        for cookie in cookies:
            s.cookies.set(cookie['name'], cookie['value'])
        return s

    def main(self):
        global running
        keyword = self.keyword.get()
        max_follow = self.max_follow.get()
        if len(max_follow) > 0:
            max_follower = int(max_follow)
        else:
            max_follower = None   
        min_follow = self.min_follow.get()
        if len(min_follow) > 0:
            min_follower = int(min_follow)
        else:
            min_follower = 0
        max_like = self.max_like.get()
        if len(max_like) > 0:
            max_likes = int(max_like)
        else:
            max_likes = None
        min_like = self.min_like.get()
        if len(min_like) > 0:
            min_likes = int(min_like)
        else:
            min_likes = 0


        if len(keyword) > 0:
            running = True
            self.check_button.config(text='Stop',bg='Red',command=self.stop)
            self.open_browser()
            url = 'http://www.instagram.com'
            self.driver.get(url)
            self.login()
            self.get_cookies()
            pages_links = self.get_pages(keyword)
            excel_filename = self.create_filename(keyword)
            sheet_title = ['username','page link','followers','likes']
            wb = Workbook()
            ws = wb.active
            ws.append(sheet_title)
            print('Keyword: {}'.format(keyword))
            for page_link in pages_links:
                if 'tags' not in page_link:
                    username = page_link.split('/')[-2] 
                    session = self.get_cookies()
                    try:
                        no_follows,average_like = self.get_page_details(page_link, session)
                        if no_follows > min_follower and average_like > min_likes:
                            if max_follower is None or no_follows < max_follower:
                                if max_likes is None or no_follows < max_likes:
                                    data = [self.id,username, page_link, no_follows,int(average_like)]
                                    self.insert(data)
                                    ws.append(data)
                                    self.iid += 1
                                    self.id += 1
                            wb.save(excel_filename)
                    except Exception as e:
                        print('{} is private account'.format(username))

            wb.save(excel_filename)
            self.finish_task(excel_filename)

        else:
            print('enter any keyword')

if __name__=='__main__':
    insta = instaApi()
    insta.init_UI()

        

